# AdaptiveSound — Teal Theme Handoff (for the coding agent)

You are working in the **`sound-engineering`** Swift Package (the AdaptiveSound
macOS app). Goal: replace the old pink/orange/gold "Sunset" theme with the new
**teal, macOS-native** theme, swap the app icon, and (optionally) wire per-device
icons. All replacement assets live in this handoff folder.

Do the steps in order. Build after each major step with `make build` (or
`swift build`) and fix any errors before moving on.

---

## 0. Theme summary

| | Old (Sunset) | New (Teal) |
|---|---|---|
| Accent | `asPink #F80791` | **`asAccent #29B6A4`** |
| Title | pink→orange→gold gradient | solid primary-label |
| Icon tile | warm dark `#140C0A` | cool dark `#0F1416` |
| Device list bg | white `asPaper` | dark inset + translucent cards |
| Selection | pink-on-white | teal-tinted row |

Teal gradient (icon only): `#0EA48C → #24C6AC → #6BEAD2`.

---

## 1. Replace the color tokens

**Overwrite** `Sources/AdaptiveSound/Color+Brand.swift` with
`swift/Color+Brand.swift` from this folder.

It keeps the same public API (`Color.asAccent`, `.asLabel`, `.asCard`,
`.asInset`, `.asSelection`, `LinearGradient.asIconFill`, `BrandFont.*`) so the
view edits below compile cleanly. `asBlue` / `asGraphite` are included as
alternate accents — leave them unless asked.

> The old file exported `asPink`, `asOrange`, `asGold`, `asDark`, `asInk`,
> `asPaper` and `LinearGradient.sunset`. Those names are **gone**. Step 2 removes
> every reference; grep `as Pink\|asOrange\|asGold\|asDark\|asInk\|asPaper\|\.sunset`
> after editing and make sure there are zero hits.

---

## 2. Update the views — `Sources/AdaptiveSound/AdaptiveSound.swift`

Apply these edits. (Token → token is usually a literal find/replace; the
structural notes tell you what the result should look like.)

### 2a. `HeaderView`
- **Icon:** replace the pink SF Symbol
  `Image(systemName: "waveform.circle.fill").foregroundColor(.asPink)` with a
  rounded-square tile using the brand mark. Simplest native version:
  ```swift
  Image(systemName: "waveform")
      .font(.system(size: 34, weight: .medium))
      .foregroundStyle(.white)
      .frame(width: 76, height: 76)
      .background(LinearGradient.asIconFill)
      .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
      .shadow(color: .black.opacity(0.45), radius: 10, y: 6)
  ```
  (Or use the bundled app-icon asset — see step 3 — via `Image("AppIconMark")`.)
- **Title:** delete the `.foregroundStyle(LinearGradient(... asPink/asOrange/asGold ...))`
  modifier on `Text("Adaptive Sound")` and replace with
  `.foregroundColor(.asLabel)`. Use `.font(BrandFont.heading)`.
- **Subtitle:** `Text("Audio Enhancement Engine").foregroundColor(.asLabelSecond)`.

### 2b. Section headers ("Engine Status", "Output Device", "Available Devices")
Make them uppercase macOS-style labels:
```swift
.font(BrandFont.sectionLabel)      // 11pt semibold
.textCase(.uppercase)
.tracking(0.6)
.foregroundColor(.asLabelTertiary)
```

### 2c. Cards (`StatusCardView`, `DeviceInfoView`)
- Replace `.background(Color.asDark.opacity(0.6))` / `0.5` with
  `.background(Color.asCard)`.
- Add a hairline: `.overlay(RoundedRectangle(cornerRadius: 9).stroke(Color.asHairline, lineWidth: 0.5))`.
- Status dot stays `.green`; the "Audio Engine Ready" text stays monospaced
  (`BrandFont.mono`).

### 2d. `DevicePickerView`
- The list well: replace `.background(Color.asPaper)` with
  `.background(Color.asInset)` and bump corner radius to `11`.

### 2e. `DeviceRowView`
- Selected background: replace `Color.asPink.opacity(0.2)` with `Color.asSelection`;
  unselected: `Color.clear` (let the inset well show through) instead of
  `Color.asDark.opacity(0.3)`.
- Checkmark: `.foregroundColor(.asAccent)`.
- Row text: name `.foregroundColor(.asLabel)`, sample-rate `.foregroundColor(.asLabelSecond)`.

### 2f. `ErrorBannerView`
- Retry button + warning icon: `.foregroundColor(.asAccent)` (was `.asPink`/`.asOrange`).
- Banner background: `Color.asAccent.opacity(0.10)`.

**Reference:** `swift/VIEW-CHANGES.md` has the same checklist in short form.

---

## 3. Swap the macOS app icon  ← (this is the "SVG doesn't work" fix)

macOS app icons must be PNG/`.icns`, **not** SVG. Replace the contents of
`Sources/AdaptiveSound/Assets.xcassets/AppIcon.appiconset/` with the files in
this folder's **`AppIcon.appiconset/`**:

```
cp AppIcon.appiconset/app-icon-512.png  <repo>/Sources/AdaptiveSound/Assets.xcassets/AppIcon.appiconset/
cp AppIcon.appiconset/app-icon-1024.png <repo>/Sources/AdaptiveSound/Assets.xcassets/AppIcon.appiconset/
cp AppIcon.appiconset/AppIcon.icns      <repo>/Sources/AdaptiveSound/Assets.xcassets/AppIcon.appiconset/
```

`Contents.json` already references `app-icon-512.png` (1x) and
`app-icon-1024.png` (2x), so no catalog edit is needed.

**Preferred / bulletproof path:** the repo ships `convert-icon.sh`, which builds
`AppIcon.icns` from the PNGs with `iconutil`. After copying the two PNGs, run:
```
./convert-icon.sh
```
This regenerates a guaranteed-valid `.icns` locally. (The `AppIcon.icns` included
here is hand-assembled with PNG-embedded entries — correct, but if `iconutil`
is available, prefer regenerating.)

> `AppIcon.iconset/` is also included if you want to run
> `iconutil -c icns AppIcon.iconset` yourself. **Rename** the `-2x` files back to
> `@2x` first (the export FS couldn't store `@`):
> `for f in AppIcon.iconset/*-2x.png; do mv "$f" "${f/-2x/@2x}"; done`

After swapping, clean build so Finder/Dock pick up the new icon:
`make clean && make build` (or delete DerivedData / the built `.app`).

---

## 4. (Optional) Per-device icons

In the screenshot every row showed a **`?`** — that means
`AudioDeviceModel.type` is resolving to `.unknown`, so `systemIcon` returns
`questionmark.circle`. Two things to do:

### 4a. Fix the fallback + use valid SF Symbols (recommended — native, scalable, tints with accent)
In `Sources/AdaptiveSound/AudioViewModel.swift`, update `systemIcon`:
```swift
var systemIcon: String {
    switch type {
    case .builtin:  return "speaker.wave.2.fill"
    case .usb:      return "cable.connector"      // macOS 13+; else "pianokeys.inverse"
    case .wireless: return "airpodspro"           // macOS 13.1+; else "headphones"
    case .unknown:  return "hifispeaker.fill"     // sensible default, not a "?"
    }
}
```
Then verify device-type detection actually sets `.builtin/.usb/.wireless`
(check where `AudioDeviceModel(type:)` is constructed from CoreAudio — likely a
transport-type lookup; if it's always `.unknown`, that's the real bug behind the
`?`). Tint the symbol with the accent in `DeviceRowView`:
`Image(systemName: device.systemIcon).foregroundStyle(Color.asLabelSecond)` for
unselected, `.asAccent` for the selected row.

### 4b. OR use the bundled custom icons (bespoke look)
`device-icons/*.svg` are 24px, `stroke="currentColor"`, stroke-width 1.6:
`speaker, airpods, airpods-pro, headphones, headphones-wired, usb-interface,
homepod, bluetooth-speaker, display, airplay, microphone`.

To use them in SwiftUI, add each as a **Symbol Image Set** (or template Image
Set) in `Assets.xcassets`, set *Render As: Template*, then:
```swift
Image("speaker").renderingMode(.template).foregroundStyle(Color.asAccent)
```
SF Symbols (4a) is less work and more native; reach for these only if you want
the exact custom shapes shown in the icon sheet.

---

## 5. Verify
- `make build` is clean; grep confirms no `asPink/asOrange/asGold/asPaper/.sunset` left.
- Run the app: title is solid white, icon tile is teal on cool-dark, the device
  list is dark with a **teal-tinted** selected row, and rows show real device
  icons (no `?`).
- App/Dock icon is the teal mark (clean build if it still shows the old one).

---

## File map (this folder)
```
INSTRUCTIONS.md            ← you are here
swift/Color+Brand.swift    ← step 1 (overwrite repo file)
swift/VIEW-CHANGES.md      ← step 2 checklist
AppIcon.appiconset/        ← step 3 drop-in (icns + 2 PNGs + Contents.json)
AppIcon.icns               ← step 3 (standalone copy)
AppIcon.iconset/           ← step 3 alt (iconutil source PNGs)
device-icons/*.svg         ← step 4b (11 audio-device icons)
brand-svg/  brand-png/     ← teal mark/favicon source + rasters (reference)
```
