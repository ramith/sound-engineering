# Adaptive Sound — native macOS theme

De-pinked. Drop-in replacement for `Color+Brand.swift` plus a few view tweaks.

## What changed
| Before | After |
|---|---|
| `asPink #F80191` everywhere | `asAccent #29B6A4` teal (alts: `.asBlue` / `.asGraphite`) |
| Pink→orange→gold gradient title | Solid `.asLabel` title (no gradient) |
| `asPaper` white device list | `asInset` dark well + translucent `asCard` rows |
| Warm brown `asDark`/`asInk` surfaces | Neutral system grays |
| Pink-on-white selected row | `asSelection` accent-tinted row |

## View edits in `AdaptiveSound.swift`
1. **HeaderView** — remove the `LinearGradient` `.foregroundStyle` on the title; use `.foregroundColor(.asLabel)`. Put the icon in a rounded-square tile filled with `LinearGradient.asIconFill` instead of a pink `waveform.circle.fill`. Subtitle → `.asLabelSecond`.
2. **Section headers** ("Engine Status" / "Output Device" / "Available Devices") — `.font(BrandFont.sectionLabel)`, `.textCase(.uppercase)`, `.tracking(0.6)`, `.foregroundColor(.asLabelTertiary)`.
3. **Cards** (status / device info) — `.background(Color.asCard)` with `.overlay(RoundedRectangle(cornerRadius: 9).stroke(Color.asHairline, lineWidth: 0.5))`.
4. **DevicePickerView** — list container `.background(Color.asInset)`; remove `Color.asPaper`.
5. **DeviceRowView** — selected `.background(Color.asSelection)`; checkmark `.foregroundColor(.asAccent)`. Unselected rows: clear background.
6. **ErrorBannerView** — retry button `.foregroundColor(.asAccent)`.

> Even more "native": swap the literal surface colors for system semantics —
> `Color(nsColor: .windowBackgroundColor)`, `.controlBackgroundColor`,
> `.separatorColor`, and `.accentColor` to inherit the user's chosen accent.
