# Handoff: Adaptive Sound — Now Playing (folder-based player redesign)

## Overview
This is a redesign of the **Now Playing** screen for the Adaptive Sound macOS audio-enhancement app. The screen lets a user pick a **local music folder**, browse every audio file found inside it (searched **recursively** through sub-folders), and play tracks with transport controls. A compact now-playing widget shows the active track's metadata, and a side panel exposes the DSP module toggles and a per-module intensity control.

The redesign reorganizes the original layout around the playlist and moves the transport (spectrum → play controls → master gain) to the **top of the playlist column** so the file list is the dominant element.

## About the Design Files
The file in this bundle (`Adaptive Sound - Now Playing.dc.html`) is a **design reference created in HTML** — a working prototype that shows the intended look, layout, and interaction behavior. **It is not production code to copy directly.**

The implementation task is to **recreate this design inside the existing Adaptive Sound codebase** (Swift Package, macOS app — `Sources/AdaptiveSound`, with a C++/Swift `AudioDSP` core). Build the UI using the project's established UI layer and patterns (SwiftUI or AppKit, whichever the app already uses) rather than porting the HTML/JS. The HTML is the spec for *what to build*, not *how to build it*.

> Note: `support.js` is the prototype's render runtime only — ignore it for implementation; it has no bearing on the production app.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, and interaction states below are final and exact. Recreate the UI to match using native macOS controls and the app's existing teal theme (the "Native Theme" token set already defined in the project).

---

## Screen: Now Playing

### Window shell
- Standard macOS window, target content size **1120 × 752 px** (resizable; the design assumes a min around this size).
- Background `#1e1e1e`, corner radius 12, title bar with traffic-light controls and centered title **"Adaptive Sound"** (13px / 600 / `rgba(255,255,255,.6)`).

### Top layout structure
Vertical stack:
1. **Title bar** — 40px tall, gradient `#323232 → #2b2b2b`, bottom hairline `rgba(0,0,0,.5)`.
2. **Toolbar** — 60px tall, background `#262626`, bottom hairline `rgba(0,0,0,.45)`.
3. **Body** — fills remaining height; horizontal split: **left transport+playlist column (flex)** + **right side panel (348px fixed)**.

### Toolbar (left → right)
- **App mark** — 30×30 rounded-8 tile, gradient `linear-gradient(160deg,#3fd0ba,#1fa893 55%,#14897a)`, 5-bar equalizer glyph in white.
- **Output Device dropdown** — pill button, height 32, bg `rgba(255,255,255,.07)`, inset ring `rgba(255,255,255,.1)`. Contents: speaker icon (stroke `#4fd2c0`), label **"Built-in Speaker"** (13px/600/`rgba(255,255,255,.9)`), sample-rate **"48 kHz"** (11px mono `rgba(255,255,255,.4)`), chevron-down. This is the **single** place the output device appears — do not duplicate it elsewhere.
- **Tab selector** — segmented control directly beside the dropdown, in a `rgba(0,0,0,.28)` track with 3px padding. Tabs: **Now Playing**, **EQ**, **Settings** (each 26px tall, 13px/600). Active tab = solid teal `rgba(41,182,164,.9)` fill with dark text `#0c1413`; inactive = transparent with `rgba(255,255,255,.62)` text. There is **no "Tab Selection" label**.
- **Spacer** (flex).
- **Volume control** — 230px wide group: speaker icon, 5px-tall track (`rgba(255,255,255,.13)`) with teal fill `linear-gradient(90deg,#1fa893,#3fd0ba)` to 75%, 15px white knob, **"75%"** label (12px/600/`rgba(255,255,255,.6)`, tabular nums).

### Left column — transport then playlist (padding 18/20/16)
**Transport sits at the TOP of this column**, above the playlist, with a hairline divider below it (`rgba(255,255,255,.08)`):

1. **Spectrum** — full column width, 50px tall, ~88 narrow bars, `gap: 2px`, each `flex: 1`, min-width 2px, radius `2px 2px 1px 1px`, fill `linear-gradient(180deg,#4fd2c0,#1f9d8b)`, anchored bottom. Bars animate vertically (scaleY 0.34 → 1.0) with per-bar staggered duration ~0.7–1.55s and delay ~0–1.3s. When paused: whole strip drops to opacity 0.4 and animation pauses.
2. **Play controls** — centered row, gap 26:
   - **Previous** — 44px circle, bg `rgba(255,255,255,.06)`, inset ring `rgba(255,255,255,.1)`; skip-back glyph `rgba(255,255,255,.85)`. Hover → `rgba(255,255,255,.12)`.
   - **Play/Pause** — 62px circle, gradient `linear-gradient(160deg,#3fd0ba,#1fa893 60%,#14897a)`, glow shadow `0 8px 22px -6px rgba(31,168,147,.7)` + inner top highlight. White play triangle / pause bars. Hover → brightness 1.08.
   - **Next** — mirror of Previous.
3. **Master Gain** — full-width slider (same visual style as the volume slider): uppercase label **"Master Gain"** (11px/600, 92px fixed), 5px track, teal fill to 68%, white knob, value **"−3.2 dB"** (12px mono `rgba(255,255,255,.6)`). Sits directly **below** the play buttons. Divider below this whole transport block.

**Playlist** (below the divider):
- **Header row**: label **"Playlist"** (11px/600 uppercase `rgba(255,255,255,.42)`) + count **"14 files · recursive"** (11px mono `rgba(255,255,255,.32)`) + spacer + **"Choose Folder…"** button (teal-tinted: bg `rgba(41,182,164,.16)`, ring `rgba(41,182,164,.5)`, folder icon `#4fd2c0`, text `#6fe0d0`). The button opens a native folder picker.
- **Current folder bar**: `rgba(0,0,0,.22)` pill with folder icon + path in mono (`~/Music/Library`), truncating with ellipsis.
- **Scrollable file list** (`overflow-y: auto`, custom thin scrollbar 9px, thumb `rgba(255,255,255,.14)`). Each **row** (padding 9/12, radius 8, gap 13):
  - **Leading slot** (22px): two-digit track index (12px mono `rgba(255,255,255,.34)`) — OR, for the active track, a 3-bar mini equalizer animation in `#4fd2c0`.
  - **Name + path**: track name (14px, weight 500 / **600 when active**, `rgba(255,255,255,.85)` / white when active) over its **relative** sub-folder path (11px mono `rgba(255,255,255,.36)`), both ellipsis-truncated.
  - **Format badge**: e.g. `FLAC`/`MP3`/`WAV`/`AAC`/`ALAC` (10px/700, padded pill). Active = `#6fe0d0` on `rgba(41,182,164,.18)`; inactive = `rgba(255,255,255,.5)` on `rgba(255,255,255,.06)`.
  - **Duration**: right-aligned 42px, 12px mono `rgba(255,255,255,.45)`, tabular nums.
  - **Active row** highlight: bg `rgba(41,182,164,.16)`, inset ring `rgba(41,182,164,.45)`. **Hover** (inactive): bg `rgba(255,255,255,.05)`.
  - **Tooltip**: hovering a row shows the **full absolute path** (folder + relative path), e.g. `~/Music/Library/Synthwave/Retrowave/Midnight Drive.mp3`. Use a native tooltip / help tag.

### Right column — side panel (348px, padding 18/20/16)
Left border hairline `rgba(255,255,255,.08)`, bg tint `rgba(0,0,0,.14)`. Vertical stack, gap 16:

1. **Now Playing widget** (compact) — card `rgba(255,255,255,.045)`, inset ring `rgba(255,255,255,.07)`, radius 11, padding 12. Layout: 52px album-art tile (gradient placeholder + note glyph) + text block: title (14px/600 white), artist (12px `rgba(255,255,255,.5)`), then a **mini progress row**: `1:23` · 3px track with teal fill `#3fd0ba` to 37% · track duration. All truncating.
2. **Active Modules** (compact multi-select) — section label "Active Modules". 2-column grid, gap 6. Each module is a clickable checkbox row (padding 8/10, radius 8): 16px rounded-4 checkbox + name (13px/500). **Multi-select** (any combination can be on). Modules: **EQ, Clarity, BRIR, Loudness, Limiter**. Checked: box filled `#29b6a4` with dark checkmark `#0c1413`, row bg `rgba(41,182,164,.1)` + ring `rgba(41,182,164,.32)`, text white. Unchecked: box transparent with 1.4px ring `rgba(255,255,255,.28)`, row bg `rgba(255,255,255,.03)`, text `rgba(255,255,255,.72)`. Hover → `rgba(255,255,255,.06)`.
3. **Intensity** (compact placeholder) — section label "Intensity". A 52px dashed-border placeholder box (`rgba(255,255,255,.025)`, border `1px dashed rgba(255,255,255,.1)`) with a lock icon + **"No module selected"** (12px mono `rgba(255,255,255,.32)`). This area intentionally stays small; it becomes the active module's intensity slider once a module is selected/focused.

---

## Interactions & Behavior
- **Choose Folder…** → native open-panel limited to directories. On selection, recursively enumerate audio files (`.flac .mp3 .wav .aac .m4a/.alac .aiff .ogg` etc.) under the chosen folder and populate the playlist. Update the folder-path bar and the "N files · recursive" count.
- **Click a playlist row** → set it as the current track and start playback (sets `playing = true`). The row gains the active highlight + animated equalizer indicator; the Now Playing widget updates.
- **Play/Pause** → toggles playback; spectrum + active-row equalizer animations run when playing and pause/dim when paused.
- **Previous / Next** → move current index by ∓1 with wrap-around (first ↔ last); both start playback.
- **Tabs** → switch the body between Now Playing / EQ / Settings panels (only Now Playing is designed here).
- **Module checkbox** → toggles that DSP module independently (multi-select).
- **Tooltips** → every playlist row exposes its absolute file path on hover.
- **Volume / Master Gain sliders** → standard drag; reflect and set values (volume 0–100%, master gain in dB).

## State Management
- `musicFolderURL: URL?` — chosen root folder.
- `tracks: [Track]` — recursively discovered files. `Track { name, relativePath, absoluteURL, format, durationSeconds }`.
- `currentIndex: Int` — index of the active track.
- `isPlaying: Bool`.
- `playheadSeconds` / `durationSeconds` — for the mini progress bar.
- `activeModules: Set<Module>` — multi-select DSP toggles (EQ, Clarity, BRIR, Loudness, Limiter).
- `outputDevice` (already managed elsewhere), `volume: Double` (0–1), `masterGainDb: Double`.
- `selectedTab: Tab`.
- Spectrum data: real FFT magnitudes from the audio engine drive bar heights (prototype uses a static animated placeholder).

## Design Tokens
**Colors**
- Window bg `#1e1e1e`; title bar `#323232`→`#2b2b2b`; toolbar `#262626`; transport/divider tints as noted.
- Accent teal: solid `#29b6a4`; light `#3fd0ba` / `#4fd2c0` / `#6fe0d0`; deep `#1fa893` / `#14897a` / `#1f9d8b`; dark-on-teal text `#0c1413`.
- Teal tints: row/active bg `rgba(41,182,164,.16)`, ring `rgba(41,182,164,.45)`, module-on bg `rgba(41,182,164,.1)`.
- Text: primary `rgba(255,255,255,.92)`; standard `rgba(255,255,255,.85)`; secondary `rgba(255,255,255,.5–.62)`; tertiary `rgba(255,255,255,.32–.42)`.
- Surfaces: card `rgba(255,255,255,.045)`; inset rings `rgba(255,255,255,.06–.1)`; recessed `rgba(0,0,0,.22–.28)`.
- Traffic lights `#ff5f57 / #febc2e / #28c840`.

**Typography**
- UI: system (`-apple-system` / SF Pro Text). Mono (paths, durations, sample rates): SF Mono / `ui-monospace`.
- Section labels: 11px / 600 / uppercase / letter-spacing .06em.
- Row title 14px; secondary 12–13px; meta 10–11px.

**Spacing / radius / shadow**
- Window radius 12; cards 11; rows/buttons 8; badges 5; checkbox 4.
- Common gaps: 6 (module grid), 13 (row internals), 16 (panel sections), 26 (transport buttons).
- Slider track 5px / radius 3; knob 15px white with `0 1px 4px rgba(0,0,0,.5)`.
- Play button glow `0 8px 22px -6px rgba(31,168,147,.7)`.

## Assets
- No bitmap assets required. All glyphs are simple icons (speaker, folder, skip, play/pause, note, lock, equalizer bars) — reproduce with SF Symbols (e.g. `speaker.wave.2`, `folder`, `backward.fill`, `play.fill`/`pause.fill`, `music.note`, `lock`). The app mark is the existing 5-bar Adaptive Sound logo (in the project's brand assets).
- Album art is a gradient placeholder; use real cover art when embedded metadata provides it.

## Files
- `Adaptive Sound - Now Playing.dc.html` — the high-fidelity design prototype (open in a browser to see live layout + interactions: folder/path bar, scrollable playlist with path tooltips, play/pause + prev/next, module toggles, animated spectrum).
- `support.js` — prototype runtime only; **ignore for implementation**.
